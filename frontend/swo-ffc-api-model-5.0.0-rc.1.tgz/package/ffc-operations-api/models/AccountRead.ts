/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type AccountRead = {
  /**
   * The name of the account
   */
  name: string;
  /**
   * An external identifier for the account
   */
  external_id: string;
  events: {
    created: {
      at: string;
      by: ({
        id: string;
        type: 'user' | 'system';
        name: string;
      } | null);
    };
    updated: {
      at: string;
      by: ({
        id: string;
        type: 'user' | 'system';
        name: string;
      } | null);
    };
    deleted?: ({
      at: string;
      by: ({
        id: string;
        type: 'user' | 'system';
        name: string;
      } | null);
    } | null);
  };
  id: string;
  account_user: ({
    status: 'invited' | 'invitation-expired' | 'active' | 'deleted';
    id: string;
    created_at?: (string | null);
    joined_at?: (string | null);
    user: {
      name: string;
      email: string;
      id: string;
    };
  } | null);
  status: 'active' | 'disabled' | 'deleted';
  type: 'operations' | 'affiliate';
  stats: {
    entitlements: {
      new?: number;
      redeemed?: number;
      terminated?: number;
    };
  };
};

