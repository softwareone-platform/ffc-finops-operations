/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type SystemCreate = {
  name: string;
  external_id: string;
  description?: (string | null);
  owner?: ({
    id: string;
  } | null);
  jwt_secret?: (string | null);
};

