/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type AccountReference = {
  id: string;
  name: string;
  type: 'operations' | 'affiliate';
};

