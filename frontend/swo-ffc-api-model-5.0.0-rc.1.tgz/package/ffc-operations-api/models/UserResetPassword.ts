/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type UserResetPassword = {
  password?: (string | null);
  pwd_reset_token: string;
};

