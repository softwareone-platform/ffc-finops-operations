/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type UserAcceptInvitation = {
  password?: (string | null);
  invitation_token: string;
};

