/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type LimitOffsetPage_SystemRead_ = {
  items: Array<{
    name: string;
    external_id: string;
    description?: (string | null);
    owner: {
      id: string;
      name: string;
      type: 'operations' | 'affiliate';
    };
    events: {
      created: {
        at: string;
        by: ({
          id: string;
          type: 'user' | 'system';
          name: string;
        } | null);
      };
      updated: {
        at: string;
        by: ({
          id: string;
          type: 'user' | 'system';
          name: string;
        } | null);
      };
      deleted?: ({
        at: string;
        by: ({
          id: string;
          type: 'user' | 'system';
          name: string;
        } | null);
      } | null);
    };
    id: string;
    status: 'active' | 'disabled' | 'deleted';
  }>;
  total?: (number | null);
  limit: (number | null);
  offset: (number | null);
};

