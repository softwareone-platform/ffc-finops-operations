/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type LoginRead = {
  user: {
    name: string;
    email: string;
    id: string;
  };
  account: {
    id: string;
    name: string;
    type: 'operations' | 'affiliate';
  };
  access_token: string;
  refresh_token: string;
};

