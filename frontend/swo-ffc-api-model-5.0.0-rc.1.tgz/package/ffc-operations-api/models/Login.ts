/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type Login = {
  email: string;
  password: string;
  account?: ({
    id: string;
  } | null);
};

