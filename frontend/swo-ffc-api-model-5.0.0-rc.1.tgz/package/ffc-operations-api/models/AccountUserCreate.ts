/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type AccountUserCreate = {
  account?: ({
    id: string;
  } | null);
  name: string;
  email: string;
};

