/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type SystemUpdate = {
  name?: (string | null);
  external_id?: (string | null);
  description?: (string | null);
  jwt_secret?: (string | null);
};

