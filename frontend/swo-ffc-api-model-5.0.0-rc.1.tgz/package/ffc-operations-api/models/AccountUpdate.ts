/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type AccountUpdate = {
  name?: (string | null);
  external_id?: (string | null);
};

