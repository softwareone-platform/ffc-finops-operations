/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type UserInvitationRead = {
  name: string;
  email: string;
  events: {
    created: {
      at: string;
      by: ({
        id: string;
        type: 'user' | 'system';
        name: string;
      } | null);
    };
    updated: {
      at: string;
      by: ({
        id: string;
        type: 'user' | 'system';
        name: string;
      } | null);
    };
    deleted?: ({
      at: string;
      by: ({
        id: string;
        type: 'user' | 'system';
        name: string;
      } | null);
    } | null);
  };
  id: string;
  account_user?: ({
    status: 'invited' | 'invitation-expired' | 'active' | 'deleted';
    events: {
      created: {
        at: string;
        by: ({
          id: string;
          type: 'user' | 'system';
          name: string;
        } | null);
      };
      updated: {
        at: string;
        by: ({
          id: string;
          type: 'user' | 'system';
          name: string;
        } | null);
      };
      deleted?: ({
        at: string;
        by: ({
          id: string;
          type: 'user' | 'system';
          name: string;
        } | null);
      } | null);
    };
    id: string;
    account: {
      id: string;
      name: string;
      type: 'operations' | 'affiliate';
    };
    user: {
      name: string;
      email: string;
      id: string;
    };
    invitation_token: (string | null);
    invitation_token_expires_at: (string | null);
    joined_at?: (string | null);
  } | null);
  status: 'draft' | 'active' | 'disabled' | 'deleted';
};

