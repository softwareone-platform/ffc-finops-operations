/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type UserRead = {
  name: string;
  email: string;
  events: {
    created: {
      at: string;
      by: ({
        id: string;
        type: 'user' | 'system';
        name: string;
      } | null);
    };
    updated: {
      at: string;
      by: ({
        id: string;
        type: 'user' | 'system';
        name: string;
      } | null);
    };
    deleted?: ({
      at: string;
      by: ({
        id: string;
        type: 'user' | 'system';
        name: string;
      } | null);
    } | null);
  };
  id: string;
  status: 'draft' | 'active' | 'disabled' | 'deleted';
  last_login_at: (string | null);
  last_used_account: ({
    id: string;
    name: string;
    type: 'operations' | 'affiliate';
  } | null);
  account_user: ({
    status: 'invited' | 'invitation-expired' | 'active' | 'deleted';
    id: string;
    created_at?: (string | null);
    joined_at?: (string | null);
    account: {
      id: string;
      name: string;
      type: 'operations' | 'affiliate';
    };
  } | null);
};

