/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type RefreshAccessToken = {
  account: {
    id: string;
  };
  refresh_token: string;
};

